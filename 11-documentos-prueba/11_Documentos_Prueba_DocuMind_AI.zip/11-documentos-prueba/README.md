# 11 - Documentos de prueba - DocuMind AI

Autor: Miguel Andres Barrios Rodriguez

Este repositorio contiene 30 documentos completamente ficticios, creados solo para pruebas académicas de DocuMind AI.

## Distribución

- 10 Contratos
- 10 Facturas
- 10 Informes

Formatos:
- 12 PDF
- 9 DOCX
- 9 TXT

Total: 30 documentos.

## Objetivo

Probar las funciones de:
- carga de archivos;
- extracción de texto;
- clasificación automática;
- generación de resumen;
- extracción de datos relevantes;
- búsqueda documental;
- preguntas en lenguaje natural.

## Datos personales

Los nombres de empresas y personas utilizados son ficticios y no corresponden intencionalmente a información personal real.
