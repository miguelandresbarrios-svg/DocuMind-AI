# 10 - Base de datos DocuMind AI

Autor: Miguel Andres Barrios Rodriguez

Esta carpeta contiene la estructura necesaria para reproducir la base de datos del proyecto DocuMind AI.

## Archivos
- `01_schema.sql`: crea la base de datos y todas las tablas.
- `02_seed_referencia.sql`: consultas de referencia para validar usuarios.
- `03_modelo_relacional.txt`: resumen de relaciones entre tablas.

## Orden de ejecución
1. Abrir MySQL Workbench.
2. Ejecutar `01_schema.sql`.
3. Verificar que exista el esquema `documind_ai`.
4. Ir al código fuente del entregable 09.
5. Copiar `.env.example` como `.env`.
6. Configurar las credenciales reales de MySQL.
7. Ejecutar `npm install`.
8. Ejecutar `npm run seed`.
9. Validar:

```sql
USE documind_ai;
SHOW TABLES;
SELECT id, name, email, role, active FROM users;
```

## Tablas
- `users`
- `repositories`
- `documents`
- `document_chunks`
- `queries`
- `processing_errors`

## Seguridad
Las contraseñas se almacenan con hash bcrypt.
Las credenciales de MySQL y API Keys deben mantenerse en `.env` y no deben publicarse en GitHub.
