USE documind_ai;

-- El usuario administrador inicial se genera mediante:
-- npm run seed
-- desde el código fuente del entregable 09.
-- Así la contraseña se almacena con hash bcrypt y no en texto plano.

SELECT id, name, email, role, active, created_at
FROM users
ORDER BY id;
