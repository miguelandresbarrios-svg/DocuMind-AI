@echo off
echo ======================================
echo          DocuMind AI
echo ======================================
if not exist .env (
  echo.
  echo ERROR: No existe .env
  echo Copia .env.example como .env y configura MySQL y Gemini.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Instalando dependencias...
  call npm install
)
echo Iniciando aplicacion...
call npm start
pause
