const express = require('express');
const db = require('../config/database');
const { authRequired } = require('../middleware/auth');

const router = express.Router();
router.use(authRequired);

router.get('/', async (req, res) => {
  const [summary] = await db.execute(
    `SELECT
       COUNT(d.id) AS total_documents,
       SUM(d.processing_status='Procesado') AS processed,
       SUM(d.processing_status='Pendiente') AS pending,
       SUM(d.processing_status='Procesando') AS processing,
       SUM(d.processing_status='Error') AS errors
     FROM repositories r
     LEFT JOIN documents d ON d.repository_id=r.id
     WHERE r.user_id=?`,
    [req.user.id]
  );

  const [categories] = await db.execute(
    `SELECT COALESCE(d.category,'Sin categoría') AS category, COUNT(*) AS total
     FROM documents d
     JOIN repositories r ON r.id=d.repository_id
     WHERE r.user_id=?
     GROUP BY d.category
     ORDER BY total DESC`,
    [req.user.id]
  );

  const [repos] = await db.execute(
    `SELECT COUNT(*) AS total_repositories FROM repositories WHERE user_id=?`,
    [req.user.id]
  );

  res.json({
    summary: { ...summary[0], total_repositories: repos[0].total_repositories },
    categories
  });
});

module.exports = router;
