const express = require('express');
const path = require('path');
const fs = require('fs/promises');
const multer = require('multer');

const db = require('../config/database');
const { authRequired } = require('../middleware/auth');
const { processDocument } = require('../services/processingService');

const router = express.Router();
router.use(authRequired);

const uploadDir = path.join(process.cwd(), 'uploads');

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_');
    cb(null, `${Date.now()}-${Math.round(Math.random() * 1e9)}-${safe}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 15 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (!['.pdf', '.docx', '.txt'].includes(ext)) {
      return cb(new Error('Solo se permiten archivos PDF, DOCX y TXT.'));
    }
    cb(null, true);
  }
});

async function repositoryOwned(repositoryId, userId) {
  const [rows] = await db.execute(
    `SELECT id FROM repositories WHERE id=? AND user_id=?`,
    [repositoryId, userId]
  );
  return Boolean(rows[0]);
}

router.get('/repository/:repositoryId', async (req, res) => {
  if (!(await repositoryOwned(req.params.repositoryId, req.user.id))) {
    return res.status(404).json({ message: 'Repositorio no encontrado.' });
  }

  const [rows] = await db.execute(
    `SELECT id, repository_id, original_name, mime_type, file_size,
            category, summary, extracted_data, processing_status,
            error_message, created_at, processed_at
     FROM documents
     WHERE repository_id=?
     ORDER BY created_at DESC`,
    [req.params.repositoryId]
  );

  res.json(rows);
});

router.post('/repository/:repositoryId', upload.single('file'), async (req, res) => {
  try {
    if (!(await repositoryOwned(req.params.repositoryId, req.user.id))) {
      if (req.file) await fs.unlink(req.file.path).catch(() => {});
      return res.status(404).json({ message: 'Repositorio no encontrado.' });
    }

    if (!req.file) return res.status(400).json({ message: 'Debe seleccionar un archivo.' });

    const [result] = await db.execute(
      `INSERT INTO documents
       (repository_id, original_name, stored_name, storage_path, mime_type, file_size, processing_status)
       VALUES (?, ?, ?, ?, ?, ?, 'Pendiente')`,
      [
        req.params.repositoryId,
        req.file.originalname,
        req.file.filename,
        req.file.path,
        req.file.mimetype,
        req.file.size
      ]
    );

    const documentId = result.insertId;

    try {
      const analysis = await processDocument(documentId);
      res.status(201).json({ id: documentId, status: 'Procesado', analysis });
    } catch (processingError) {
      res.status(202).json({
        id: documentId,
        status: 'Error',
        message: processingError.message
      });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'No fue posible cargar el documento.' });
  }
});

router.get('/:id', async (req, res) => {
  const [rows] = await db.execute(
    `SELECT d.*
     FROM documents d
     JOIN repositories r ON r.id=d.repository_id
     WHERE d.id=? AND r.user_id=?`,
    [req.params.id, req.user.id]
  );

  if (!rows[0]) return res.status(404).json({ message: 'Documento no encontrado.' });
  res.json(rows[0]);
});

router.get('/:id/download', async (req, res) => {
  const [rows] = await db.execute(
    `SELECT d.original_name, d.storage_path
     FROM documents d
     JOIN repositories r ON r.id=d.repository_id
     WHERE d.id=? AND r.user_id=?`,
    [req.params.id, req.user.id]
  );

  const doc = rows[0];
  if (!doc) return res.status(404).json({ message: 'Documento no encontrado.' });
  res.download(doc.storage_path, doc.original_name);
});

router.delete('/:id', async (req, res) => {
  const [rows] = await db.execute(
    `SELECT d.storage_path
     FROM documents d
     JOIN repositories r ON r.id=d.repository_id
     WHERE d.id=? AND r.user_id=?`,
    [req.params.id, req.user.id]
  );

  const doc = rows[0];
  if (!doc) return res.status(404).json({ message: 'Documento no encontrado.' });

  await db.execute(`DELETE FROM documents WHERE id=?`, [req.params.id]);
  await fs.unlink(doc.storage_path).catch(() => {});
  res.json({ message: 'Documento eliminado.' });
});

module.exports = router;
