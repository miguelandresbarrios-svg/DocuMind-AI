const express = require('express');
const db = require('../config/database');
const { authRequired } = require('../middleware/auth');
const { rankChunks } = require('../services/retrievalService');
const { answerQuestion } = require('../services/aiService');

const router = express.Router();
router.use(authRequired);

async function loadChunks(userId, repositoryId = null) {
  let sql = `
    SELECT dc.id, dc.document_id, dc.content, d.original_name AS file_name
    FROM document_chunks dc
    JOIN documents d ON d.id=dc.document_id
    JOIN repositories r ON r.id=d.repository_id
    WHERE r.user_id=? AND d.processing_status='Procesado'
  `;
  const params = [userId];

  if (repositoryId) {
    sql += ` AND r.id=?`;
    params.push(repositoryId);
  }

  const [rows] = await db.execute(sql, params);
  return rows;
}

router.post('/', async (req, res) => {
  const { query, repositoryId = null } = req.body;
  if (!query?.trim()) return res.status(400).json({ message: 'La búsqueda está vacía.' });

  const chunks = await loadChunks(req.user.id, repositoryId);
  const results = rankChunks(query, chunks, 10);

  res.json(results);
});

router.post('/ask', async (req, res) => {
  try {
    const { question, repositoryId = null } = req.body;
    if (!question?.trim()) return res.status(400).json({ message: 'La pregunta está vacía.' });

    const chunks = await loadChunks(req.user.id, repositoryId);
    const contexts = rankChunks(question, chunks, 6);

    if (!contexts.length) {
      return res.json({
        answer: 'No encuentro esa información en los documentos consultados.',
        sources: []
      });
    }

    const answer = await answerQuestion(question, contexts);

    await db.execute(
      `INSERT INTO queries(user_id, repository_id, question, answer)
       VALUES (?, ?, ?, ?)`,
      [req.user.id, repositoryId || null, question, answer]
    ).catch(async () => {
      await db.execute(
        `INSERT INTO queries(user_id, repository_id, question, answer)
         VALUES (?, NULL, ?, ?)`,
        [req.user.id, question, answer]
      );
    });

    res.json({
      answer,
      sources: contexts.map(c => ({
        documentId: c.document_id,
        fileName: c.file_name,
        excerpt: c.content.slice(0, 260)
      }))
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'No fue posible responder la pregunta.', detail: error.message });
  }
});

module.exports = router;
