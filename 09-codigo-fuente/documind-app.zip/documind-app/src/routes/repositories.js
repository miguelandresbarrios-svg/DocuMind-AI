const express = require('express');
const db = require('../config/database');
const { authRequired } = require('../middleware/auth');

const router = express.Router();
router.use(authRequired);

router.get('/', async (req, res) => {
  const [rows] = await db.execute(
    `SELECT r.id, r.name, r.description, r.created_at,
            COUNT(d.id) AS document_count
     FROM repositories r
     LEFT JOIN documents d ON d.repository_id = r.id
     WHERE r.user_id=?
     GROUP BY r.id
     ORDER BY r.created_at DESC`,
    [req.user.id]
  );
  res.json(rows);
});

router.post('/', async (req, res) => {
  try {
    const { name, description = '' } = req.body;
    if (!name?.trim()) return res.status(400).json({ message: 'El nombre es obligatorio.' });

    const [result] = await db.execute(
      `INSERT INTO repositories(user_id, name, description)
       VALUES (?, ?, ?)`,
      [req.user.id, name.trim(), description.trim()]
    );

    res.status(201).json({ id: result.insertId, name, description });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ message: 'Ya existe un repositorio con ese nombre.' });
    }
    console.error(error);
    res.status(500).json({ message: 'No fue posible crear el repositorio.' });
  }
});

router.delete('/:id', async (req, res) => {
  const [rows] = await db.execute(
    `SELECT id FROM repositories WHERE id=? AND user_id=?`,
    [req.params.id, req.user.id]
  );
  if (!rows[0]) return res.status(404).json({ message: 'Repositorio no encontrado.' });

  await db.execute(`DELETE FROM repositories WHERE id=?`, [req.params.id]);
  res.json({ message: 'Repositorio eliminado.' });
});

module.exports = router;
