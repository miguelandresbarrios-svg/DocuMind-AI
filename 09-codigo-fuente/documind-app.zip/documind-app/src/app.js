const path = require('path');
require('dotenv').config({ path: path.join(process.cwd(), '.env') });

const express = require('express');
const cors = require('cors');
const fs = require('fs');

const db = require('./config/database');

const authRoutes = require('./routes/auth');
const repositoryRoutes = require('./routes/repositories');
const documentRoutes = require('./routes/documents');
const searchRoutes = require('./routes/search');
const dashboardRoutes = require('./routes/dashboard');

const app = express();
const PORT = Number(process.env.PORT || 3000);

fs.mkdirSync(path.join(process.cwd(), 'uploads'), { recursive: true });

app.use(cors());
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(process.cwd(), 'public')));

app.use('/api/auth', authRoutes);
app.use('/api/repositories', repositoryRoutes);
app.use('/api/documents', documentRoutes);
app.use('/api/search', searchRoutes);
app.use('/api/dashboard', dashboardRoutes);

app.get('/api/health', async (_req, res) => {
  try {
    await db.query('SELECT 1');
    res.json({ status: 'ok', database: 'ok', aiMode: process.env.AI_MODE || 'gemini' });
  } catch (error) {
    res.status(500).json({ status: 'error', database: error.message });
  }
});

app.get('*', (_req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'index.html'));
});

app.use((error, _req, res, _next) => {
  console.error(error);
  res.status(400).json({ message: error.message || 'Error de la solicitud.' });
});

app.listen(PORT, async () => {
  console.log(`🚀 DocuMind AI ejecutándose en http://localhost:${PORT}`);
  try {
    await db.query('SELECT 1');
    console.log('✅ Conexión a MySQL correcta');
  } catch (error) {
    console.error('❌ Error de MySQL:', error.message);
  }
});
