const fs = require('fs/promises');
const path = require('path');
const pdfParse = require('pdf-parse');
const mammoth = require('mammoth');

async function extractText(filePath, originalName) {
  const ext = path.extname(originalName).toLowerCase();

  if (ext === '.txt') {
    return (await fs.readFile(filePath, 'utf8')).trim();
  }

  if (ext === '.pdf') {
    const buffer = await fs.readFile(filePath);
    const data = await pdfParse(buffer);
    return (data.text || '').trim();
  }

  if (ext === '.docx') {
    const result = await mammoth.extractRawText({ path: filePath });
    return (result.value || '').trim();
  }

  throw new Error('Formato no soportado. Solo se permiten PDF, DOCX y TXT.');
}

module.exports = { extractText };
