const fs = require('fs/promises');
const path = require('path');
const mammoth = require('mammoth');
const { pathToFileURL } = require('url');

async function extractPdfText(filePath) {
  const pdfjsLib = await import(
    'pdfjs-dist/legacy/build/pdf.mjs'
  );

  const buffer = await fs.readFile(filePath);

  const standardFontsPath = path.join(
    process.cwd(),
    'node_modules',
    'pdfjs-dist',
    'standard_fonts'
  );

  // PDF.js necesita una URL file:/// válida y terminada en /
  const standardFontDataUrl =
    pathToFileURL(standardFontsPath).href + '/';

  const pdf = await pdfjsLib.getDocument({
    data: new Uint8Array(buffer),
    standardFontDataUrl,
    useSystemFonts: true
  }).promise;

  let fullText = '';

  for (
    let pageNumber = 1;
    pageNumber <= pdf.numPages;
    pageNumber++
  ) {
    const page = await pdf.getPage(pageNumber);

    const content = await page.getTextContent();

    const pageText = content.items
      .map(item => item.str)
      .join(' ');

    fullText += pageText + '\n';
  }

  return fullText.trim();
}

async function extractText(filePath, originalName) {
  const ext = path.extname(originalName).toLowerCase();

  if (ext === '.txt') {
    return (await fs.readFile(filePath, 'utf8')).trim();
  }

  if (ext === '.pdf') {
    return await extractPdfText(filePath);
  }

  if (ext === '.docx') {
    const result = await mammoth.extractRawText({
      path: filePath
    });

    return (result.value || '').trim();
  }

  throw new Error(
    'Formato no soportado. Solo se permiten PDF, DOCX y TXT.'
  );
}

module.exports = {
  extractText
};