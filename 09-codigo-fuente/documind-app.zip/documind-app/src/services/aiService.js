let clientPromise = null;

async function getClient() {
  if (
    !process.env.GEMINI_API_KEY ||
    process.env.GEMINI_API_KEY.startsWith('PEGA_')
  ) {
    throw new Error(
      'El servicio de inteligencia artificial no está configurado.'
    );
  }

  if (!clientPromise) {
    clientPromise = import('@google/genai').then(({ GoogleGenAI }) => {
      return new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY
      });
    });
  }

  return clientPromise;
}

function cleanJson(text = '') {
  return text
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/```$/i, '')
    .trim();
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function askGemini(prompt) {
  const ai = await getClient();

  const model =
    process.env.GEMINI_MODEL ||
    'gemini-flash-latest';

  const maxRetries = 3;

  for (
    let attempt = 0;
    attempt <= maxRetries;
    attempt++
  ) {
    try {
      const interaction =
        await ai.interactions.create({
          model,
          input: prompt,
          store: false
        });

      return interaction.output_text || '';

    } catch (error) {
      const message =
        error?.message || String(error);

      const isRateLimit =
        message.includes('429') ||
        message.includes('RESOURCE_EXHAUSTED') ||
        message.toLowerCase().includes('quota') ||
        message.toLowerCase().includes(
          'rate limit'
        );

      // Si el error NO es por límite de uso,
      // se devuelve normalmente.
      if (!isRateLimit) {
        throw error;
      }

      // Si ya se agotaron los reintentos,
      // devolvemos un mensaje entendible
      // para mostrarlo en la interfaz.
      if (attempt === maxRetries) {
        throw new Error(
          'El servicio de inteligencia artificial ' +
          'alcanzó temporalmente su límite de uso. ' +
          'Espera unos minutos e intenta nuevamente.'
        );
      }

      // Espera progresiva:
      // 5 segundos
      // 10 segundos
      // 20 segundos
      const waitTime =
        5000 * Math.pow(2, attempt);

      console.log(
        `Límite temporal de Gemini. ` +
        `Reintento ${attempt + 1}/${maxRetries} ` +
        `en ${waitTime / 1000} segundos...`
      );

      await sleep(waitTime);
    }
  }

  throw new Error(
    'No fue posible obtener una respuesta ' +
    'del servicio de inteligencia artificial.'
  );
}

async function analyzeDocument(
  text,
  fileName
) {
  const prompt = `
Eres un analista documental empresarial.
Analiza el documento siguiente.

Debes devolver EXCLUSIVAMENTE JSON válido,
sin Markdown ni explicaciones,
con esta estructura:

{
  "categoria": "Contrato|Factura|Informe|Otro",
  "resumen": "resumen breve y fiel",
  "datos_extraidos": {
    "numero_factura": null,
    "proveedor": null,
    "fecha": null,
    "valor_total": null,
    "concepto": null,
    "partes": null,
    "objeto": null,
    "valor": null,
    "vigencia": null,
    "titulo": null,
    "responsable": null,
    "tema_principal": null,
    "conclusiones": null
  }
}

Reglas:
- No inventes datos.
- Usa null cuando un dato no aparezca.
- Clasifica principalmente como Contrato,
  Factura o Informe cuando corresponda.
- El resumen debe representar
  el contenido real.
- No agregues información que no exista
  en el documento.

Archivo:
${fileName}

Contenido:
${text.slice(0, 30000)}
`;

  const raw =
    await askGemini(prompt);

  try {
    return JSON.parse(
      cleanJson(raw)
    );
  } catch (error) {
    throw new Error(
      'La inteligencia artificial respondió, ' +
      'pero el resultado no pudo ser interpretado.'
    );
  }
}

async function answerQuestion(
  question,
  contexts
) {
  const contextText =
    contexts
      .map(
        (c, i) =>
          `[Fragmento ${i + 1} - ${c.file_name}]
${c.content}`
      )
      .join('\n\n');

  const prompt = `
Responde la pregunta usando únicamente
el CONTEXTO documental proporcionado.

Si la respuesta no aparece en el contexto,
responde exactamente:

"No encuentro esa información
en los documentos consultados."

Reglas:
- No inventes datos.
- No uses información externa.
- Responde de forma clara y breve.
- Utiliza únicamente la información
  presente en los fragmentos proporcionados.

PREGUNTA:
${question}

CONTEXTO:
${contextText}
`;

  return (
    await askGemini(prompt)
  ).trim();
}

module.exports = {
  analyzeDocument,
  answerQuestion
};