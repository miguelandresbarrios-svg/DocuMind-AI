let clientPromise = null;

async function getClient() {
  if (!process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY.startsWith('PEGA_')) {
    throw new Error('GEMINI_API_KEY no está configurada.');
  }

  if (!clientPromise) {
    clientPromise = import('@google/genai').then(({ GoogleGenAI }) => {
      return new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    });
  }

  return clientPromise;
}

function cleanJson(text = '') {
  return text
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/```$/i, '')
    .trim();
}

async function askGemini(prompt) {
  const ai = await getClient();
  const model = process.env.GEMINI_MODEL || 'gemini-3.8-flash';

  const interaction = await ai.interactions.create({
    model,
    input: prompt,
    store: false
  });

  return interaction.output_text || '';
}

async function analyzeDocument(text, fileName) {
  const prompt = `
Eres un analista documental empresarial. Analiza el documento siguiente.

Debes devolver EXCLUSIVAMENTE JSON válido, sin Markdown ni explicaciones, con esta estructura:
{
  "categoria": "Contrato|Factura|Informe|Otro",
  "resumen": "resumen breve y fiel",
  "datos_extraidos": {
    "numero_factura": null,
    "proveedor": null,
    "fecha": null,
    "valor_total": null,
    "concepto": null,
    "partes": null,
    "objeto": null,
    "valor": null,
    "vigencia": null,
    "titulo": null,
    "responsable": null,
    "tema_principal": null,
    "conclusiones": null
  }
}

Reglas:
- No inventes datos.
- Usa null cuando un dato no aparezca.
- Clasifica principalmente como Contrato, Factura o Informe cuando corresponda.
- El resumen debe representar el contenido real.

Archivo: ${fileName}

Contenido:
${text.slice(0, 30000)}
`;

  const raw = await askGemini(prompt);
  const parsed = JSON.parse(cleanJson(raw));
  return parsed;
}

async function answerQuestion(question, contexts) {
  const contextText = contexts
    .map((c, i) => `[Fragmento ${i + 1} - ${c.file_name}]\n${c.content}`)
    .join('\n\n');

  const prompt = `
Responde la pregunta usando únicamente el CONTEXTO documental proporcionado.

Si la respuesta no aparece en el contexto, responde:
"No encuentro esa información en los documentos consultados."

No inventes datos. Sé claro y breve.

PREGUNTA:
${question}

CONTEXTO:
${contextText}
`;

  return (await askGemini(prompt)).trim();
}

module.exports = { analyzeDocument, answerQuestion };
