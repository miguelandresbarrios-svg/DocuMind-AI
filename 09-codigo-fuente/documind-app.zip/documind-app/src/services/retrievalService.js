function chunkText(text, size = 1200, overlap = 180) {
  const clean = text.replace(/\s+/g, ' ').trim();
  if (!clean) return [];

  const chunks = [];
  let start = 0;

  while (start < clean.length) {
    const end = Math.min(start + size, clean.length);
    chunks.push(clean.slice(start, end));
    if (end === clean.length) break;
    start = Math.max(0, end - overlap);
  }

  return chunks;
}

function tokenize(text = '') {
  return new Set(
    text
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9áéíóúñü\s]/gi, ' ')
      .split(/\s+/)
      .filter(word => word.length > 2)
  );
}

function scoreChunk(query, chunk) {
  const q = tokenize(query);
  const c = tokenize(chunk);
  let score = 0;
  for (const token of q) {
    if (c.has(token)) score += 1;
  }
  return score;
}

function rankChunks(query, chunks, limit = 6) {
  return chunks
    .map(item => ({ ...item, score: scoreChunk(query, item.content) }))
    .sort((a, b) => b.score - a.score)
    .filter(item => item.score > 0)
    .slice(0, limit);
}

module.exports = { chunkText, rankChunks };
