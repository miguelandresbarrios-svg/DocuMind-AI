const db = require('../config/database');
const { extractText } = require('./documentExtractor');
const { analyzeDocument } = require('./aiService');
const { chunkText } = require('./retrievalService');

async function processDocument(documentId) {
  const [rows] = await db.execute(
    `SELECT d.*, r.user_id
     FROM documents d
     JOIN repositories r ON r.id = d.repository_id
     WHERE d.id = ?`,
    [documentId]
  );

  const doc = rows[0];
  if (!doc) throw new Error('Documento no encontrado.');

  await db.execute(
    `UPDATE documents SET processing_status='Procesando', error_message=NULL WHERE id=?`,
    [documentId]
  );

  try {
    const text = await extractText(doc.storage_path, doc.original_name);

    if (!text || text.length < 10) {
      throw new Error('No fue posible extraer suficiente contenido textual.');
    }

    const analysis = await analyzeDocument(text, doc.original_name);

    await db.execute(
      `UPDATE documents
       SET extracted_text=?, category=?, summary=?, extracted_data=?,
           processing_status='Procesado', processed_at=NOW()
       WHERE id=?`,
      [
        text,
        analysis.categoria || 'Otro',
        analysis.resumen || '',
        JSON.stringify(analysis.datos_extraidos || {}),
        documentId
      ]
    );

    await db.execute(`DELETE FROM document_chunks WHERE document_id=?`, [documentId]);

    const chunks = chunkText(text);
    for (let i = 0; i < chunks.length; i++) {
      await db.execute(
        `INSERT INTO document_chunks(document_id, chunk_index, content)
         VALUES (?, ?, ?)`,
        [documentId, i, chunks[i]]
      );
    }

    return analysis;
  } catch (error) {
    await db.execute(
      `UPDATE documents
       SET processing_status='Error', error_message=?
       WHERE id=?`,
      [error.message.slice(0, 1000), documentId]
    );

    await db.execute(
      `INSERT INTO processing_errors(document_id, error_message)
       VALUES (?, ?)`,
      [documentId, error.message.slice(0, 1000)]
    );

    throw error;
  }
}

module.exports = { processDocument };
