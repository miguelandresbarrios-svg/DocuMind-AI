CREATE DATABASE IF NOT EXISTS documind_ai
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE documind_ai;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('ADMIN','USER') NOT NULL DEFAULT 'USER',
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS repositories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  name VARCHAR(120) NOT NULL,
  description VARCHAR(500) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_repository_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE,
  CONSTRAINT uq_repository_user_name UNIQUE(user_id, name)
);

CREATE TABLE IF NOT EXISTS documents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  repository_id INT NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  stored_name VARCHAR(255) NOT NULL,
  storage_path VARCHAR(600) NOT NULL,
  mime_type VARCHAR(120) NULL,
  file_size BIGINT NOT NULL DEFAULT 0,
  category VARCHAR(80) NULL,
  summary TEXT NULL,
  extracted_data JSON NULL,
  extracted_text LONGTEXT NULL,
  processing_status ENUM('Pendiente','Procesando','Procesado','Error')
    NOT NULL DEFAULT 'Pendiente',
  error_message TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  processed_at DATETIME NULL,
  CONSTRAINT fk_document_repository
    FOREIGN KEY (repository_id) REFERENCES repositories(id)
    ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS document_chunks (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  document_id INT NOT NULL,
  chunk_index INT NOT NULL,
  content TEXT NOT NULL,
  CONSTRAINT fk_chunk_document
    FOREIGN KEY (document_id) REFERENCES documents(id)
    ON DELETE CASCADE,
  INDEX idx_chunk_document(document_id)
);

CREATE TABLE IF NOT EXISTS queries (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  repository_id INT NULL,
  question TEXT NOT NULL,
  answer TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_query_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE,
  CONSTRAINT fk_query_repository
    FOREIGN KEY (repository_id) REFERENCES repositories(id)
    ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS processing_errors (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  document_id INT NOT NULL,
  error_message TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_error_document
    FOREIGN KEY (document_id) REFERENCES documents(id)
    ON DELETE CASCADE
);
