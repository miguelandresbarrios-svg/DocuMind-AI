const path = require('path');
require('dotenv').config({ path: path.join(process.cwd(), '.env') });

const bcrypt = require('bcryptjs');
const db = require('../src/config/database');

async function main() {
  const name = process.env.ADMIN_NAME || 'Administrador DocuMind';
  const email = process.env.ADMIN_EMAIL || 'admin@documind.local';
  const password = process.env.ADMIN_PASSWORD || 'Admin123*';

  const hash = await bcrypt.hash(password, 12);

  await db.execute(
    `INSERT INTO users(name, email, password_hash, role, active)
     VALUES (?, ?, ?, 'ADMIN', TRUE)
     ON DUPLICATE KEY UPDATE
       name=VALUES(name),
       password_hash=VALUES(password_hash),
       role='ADMIN',
       active=TRUE`,
    [name, email, hash]
  );

  console.log(`✅ Usuario administrador listo: ${email}`);
  console.log('⚠️ Cambia la contraseña antes de una entrega real.');
  await db.end();
}

main().catch(error => {
  console.error(error);
  process.exit(1);
});
