const state = {
  token: localStorage.getItem('documind_token'),
  user: JSON.parse(localStorage.getItem('documind_user') || 'null'),
  repositories: [],
  selectedRepo: null
};

const $ = id => document.getElementById(id);

function headers(json = true) {
  const h = { Authorization: `Bearer ${state.token}` };
  if (json) h['Content-Type'] = 'application/json';
  return h;
}

async function api(url, options = {}) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));
  if (response.status === 401) logout();
  if (!response.ok) throw new Error(data.message || data.detail || 'Error de la solicitud');
  return data;
}

function showApp() {
  $('loginView').classList.add('hidden');
  $('appView').classList.remove('hidden');
  $('userLabel').textContent = `${state.user.name} · ${state.user.role}`;
  loadDashboard();
  loadRepositories();
}

function logout() {
  localStorage.removeItem('documind_token');
  localStorage.removeItem('documind_user');
  location.reload();
}

$('loginForm').addEventListener('submit', async e => {
  e.preventDefault();
  $('loginMessage').textContent = 'Ingresando...';
  try {
    const data = await api('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: $('email').value,
        password: $('password').value
      })
    });
    state.token = data.token;
    state.user = data.user;
    localStorage.setItem('documind_token', data.token);
    localStorage.setItem('documind_user', JSON.stringify(data.user));
    showApp();
  } catch (error) {
    $('loginMessage').textContent = error.message;
  }
});

$('logoutBtn').addEventListener('click', logout);

document.querySelectorAll('.nav[data-section]').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav[data-section]').forEach(x => x.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.section').forEach(x => x.classList.add('hidden'));
    $(btn.dataset.section).classList.remove('hidden');
    $('sectionTitle').textContent = btn.textContent;
    if (btn.dataset.section === 'dashboard') loadDashboard();
  });
});

async function loadDashboard() {
  try {
    const data = await api('/api/dashboard', { headers: headers(false) });
    $('mRepos').textContent = data.summary.total_repositories || 0;
    $('mTotal').textContent = data.summary.total_documents || 0;
    $('mProcessed').textContent = data.summary.processed || 0;
    $('mErrors').textContent = data.summary.errors || 0;
    $('categoryList').innerHTML = (data.categories || []).map(c =>
      `<div class="category-row"><span>${c.category}</span><strong>${c.total}</strong></div>`
    ).join('') || '<p class="muted">Aún no hay documentos.</p>';
  } catch (e) { console.error(e); }
}

$('repoForm').addEventListener('submit', async e => {
  e.preventDefault();
  await api('/api/repositories', {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify({
      name: $('repoName').value,
      description: $('repoDescription').value
    })
  });
  e.target.reset();
  await loadRepositories();
  await loadDashboard();
});

async function loadRepositories() {
  state.repositories = await api('/api/repositories', { headers: headers(false) });
  $('repoList').innerHTML = state.repositories.map(r => `
    <div class="repo-item" onclick="selectRepo(${r.id})">
      <strong>${escapeHtml(r.name)}</strong>
      <span class="muted">${escapeHtml(r.description || '')}</span>
      <div class="muted">${r.document_count} documento(s)</div>
    </div>
  `).join('') || '<p class="muted">No tienes repositorios todavía.</p>';
}

window.selectRepo = async function(id) {
  state.selectedRepo = state.repositories.find(r => Number(r.id) === Number(id));
  $('documentsPanel').classList.remove('hidden');
  $('selectedRepoName').textContent = state.selectedRepo.name;
  $('selectedRepoDescription').textContent = state.selectedRepo.description || '';
  await loadDocuments();
};

$('uploadForm').addEventListener('submit', async e => {
  e.preventDefault();
  if (!state.selectedRepo) return;
  const file = $('fileInput').files[0];
  if (!file) return;

  $('uploadMessage').textContent = 'Cargando, extrayendo y procesando con IA...';
  const fd = new FormData();
  fd.append('file', file);

  try {
    const response = await fetch(`/api/documents/repository/${state.selectedRepo.id}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${state.token}` },
      body: fd
    });
    const data = await response.json();
    $('uploadMessage').textContent =
      data.status === 'Procesado'
        ? 'Documento procesado correctamente.'
        : `Documento guardado con estado ${data.status}: ${data.message || ''}`;
    $('fileInput').value = '';
    await loadDocuments();
    await loadDashboard();
    await loadRepositories();
  } catch (error) {
    $('uploadMessage').textContent = error.message;
  }
});

async function loadDocuments() {
  const docs = await api(`/api/documents/repository/${state.selectedRepo.id}`, {
    headers: headers(false)
  });

  $('documentList').innerHTML = docs.map(d => `
    <div class="doc-item">
      <strong>${escapeHtml(d.original_name)}</strong>
      <div class="muted">${escapeHtml(d.category || 'Sin categoría')} · ${formatBytes(d.file_size)}</div>
      <span class="status ${d.processing_status}">${d.processing_status}</span>
      ${d.error_message ? `<div class="muted">${escapeHtml(d.error_message)}</div>` : ''}
      <div class="doc-actions">
        <button onclick="viewDocument(${d.id})">Ver análisis</button>
        <button onclick="downloadDocument(${d.id})">Descargar</button>
        <button class="delete-btn" onclick="deleteDocument(${d.id})">Eliminar</button>
      </div>
    </div>
  `).join('') || '<p class="muted">No hay documentos en este repositorio.</p>';
}

window.viewDocument = async function(id) {
  const d = await api(`/api/documents/${id}`, { headers: headers(false) });
  let extracted = {};
  try {
    extracted = typeof d.extracted_data === 'string' ? JSON.parse(d.extracted_data) : (d.extracted_data || {});
  } catch {}

  $('documentDetail').innerHTML = `
    <h2>${escapeHtml(d.original_name)}</h2>
    <p><span class="status ${d.processing_status}">${d.processing_status}</span> · ${escapeHtml(d.category || '')}</p>
    <h3>Resumen</h3>
    <p>${escapeHtml(d.summary || 'Aún no disponible.')}</p>
    <h3>Información extraída</h3>
    <pre>${escapeHtml(JSON.stringify(extracted, null, 2))}</pre>
  `;
  $('documentDialog').showModal();
};

window.downloadDocument = function(id) {
  fetch(`/api/documents/${id}/download`, { headers: headers(false) })
    .then(async r => {
      if (!r.ok) throw new Error('No fue posible descargar.');
      const blob = await r.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = '';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    });
};

window.deleteDocument = async function(id) {
  if (!confirm('¿Eliminar este documento?')) return;
  await api(`/api/documents/${id}`, { method: 'DELETE', headers: headers(false) });
  await loadDocuments();
  await loadDashboard();
  await loadRepositories();
};

$('closeDialog').addEventListener('click', () => $('documentDialog').close());

$('searchBtn').addEventListener('click', async () => {
  const query = $('searchInput').value.trim();
  if (!query) return;
  const results = await api('/api/search', {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify({ query })
  });
  $('searchResults').innerHTML = results.map(r => `
    <div class="search-item">
      <strong>${escapeHtml(r.file_name)}</strong>
      <div class="muted">Relevancia lexical: ${r.score}</div>
      <p>${escapeHtml(r.content.slice(0, 500))}</p>
    </div>
  `).join('') || '<p class="muted">No se encontraron fragmentos relacionados.</p>';
});

$('askBtn').addEventListener('click', async () => {
  const question = $('questionInput').value.trim();
  if (!question) return;
  $('answerBox').innerHTML = '<p class="muted">Consultando documentos...</p>';

  try {
    const data = await api('/api/search/ask', {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ question })
    });

    $('answerBox').innerHTML = `
      <div class="answer">
        <strong>Respuesta</strong>
        <p>${escapeHtml(data.answer)}</p>
        ${(data.sources || []).map(s => `
          <div class="source"><strong>${escapeHtml(s.fileName)}</strong><br>${escapeHtml(s.excerpt)}</div>
        `).join('')}
      </div>
    `;
  } catch (e) {
    $('answerBox').innerHTML = `<div class="answer">${escapeHtml(e.message)}</div>`;
  }
});

function formatBytes(bytes) {
  const n = Number(bytes || 0);
  if (n < 1024) return `${n} B`;
  if (n < 1024*1024) return `${(n/1024).toFixed(1)} KB`;
  return `${(n/1024/1024).toFixed(1)} MB`;
}

function escapeHtml(value='') {
  return String(value)
    .replaceAll('&','&amp;')
    .replaceAll('<','&lt;')
    .replaceAll('>','&gt;')
    .replaceAll('"','&quot;')
    .replaceAll("'","&#039;");
}

if (state.token && state.user) showApp();
