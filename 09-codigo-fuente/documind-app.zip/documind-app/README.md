# DocuMind AI - Código fuente

Autor: Miguel Andres Barrios Rodriguez

Sistema web para gestionar repositorios documentales y aplicar IA a archivos PDF, DOCX y TXT.

## Funciones incluidas

- Inicio de sesión con JWT.
- Repositorios por usuario.
- Carga, consulta, descarga y eliminación de PDF, DOCX y TXT.
- Extracción de texto.
- Procesamiento con Gemini.
- Clasificación: Contrato, Factura, Informe u Otro.
- Resumen automático.
- Extracción de datos relevantes.
- Estados: Pendiente, Procesando, Procesado y Error.
- Registro de errores.
- Búsqueda dentro de fragmentos documentales.
- Consulta en lenguaje natural usando recuperación de fragmentos + Gemini.
- Dashboard.

## Requisitos

- Node.js 20 o superior.
- MySQL 8.
- Clave de Gemini API.

## Instalación

1. Abre MySQL Workbench.
2. Ejecuta `database/schema.sql`.
3. Copia `.env.example` como `.env`.
4. Configura `DB_PASSWORD`, `JWT_SECRET` y `GEMINI_API_KEY`.
5. Instala dependencias:

```bash
npm install
```

6. Crea el usuario administrador:

```bash
npm run seed
```

7. Inicia la aplicación:

```bash
npm start
```

8. Abre:

`http://localhost:3000`

## Usuario inicial

Los datos se configuran en `.env`:

- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`

## Flujo de IA

Documento -> almacenamiento -> extracción de texto -> Gemini -> clasificación/resumen/extracción -> MySQL -> fragmentación -> búsqueda -> recuperación de contexto -> Gemini -> respuesta.

## Seguridad

- `.env` está excluido por `.gitignore`.
- Contraseñas almacenadas con bcrypt.
- API protegida mediante JWT.
- Consultas MySQL parametrizadas.

## Nota académica

Las evidencias del documento de pruebas deben completarse solo después de ejecutar realmente los casos de prueba.
